package br.com.fiapx.common.event;

import java.time.LocalDateTime;
import java.util.UUID;

public record VideoNotificationEvent(
        UUID videoId,
        UUID userId,
        String userEmail,
        String subject,
        String message,
        LocalDateTime sentAt
) {
}
