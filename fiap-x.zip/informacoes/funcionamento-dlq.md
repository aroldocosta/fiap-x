# DLQ no FIAP-X

Este material resume:

- onde a DLQ foi configurada no projeto
- como o redrive funciona
- por que o Java também precisou ser ajustado
- como isso se compara com `SQS`, `RabbitMQ` e `Kafka`

---

## 1. Onde a DLQ foi configurada no FIAP-X

Sim, a parte principal foi no script:

- `docker/localstack/init/01-create-sqs-queues.sh`

Mas não foi só isso.

### 1.1. Onde configurei que os erros devem ser redirecionados para DLQ

O redirecionamento para DLQ foi configurado na própria fila SQS, não no Java.

Isso fica em:

- `docker/localstack/init/01-create-sqs-queues.sh`

Nesse script, a fila principal recebe o atributo `RedrivePolicy`.

Essa policy aponta a fila principal para sua DLQ correspondente:

- `video-uploaded-queue` -> `video-uploaded-queue-dlq`
- `video-status-api-queue` -> `video-status-api-queue-dlq`
- `video-status-notification-queue` -> `video-status-notification-queue-dlq`

### 1.2. Onde configurei o máximo de tentativas antes da DLQ

Também no mesmo script:

- `docker/localstack/init/01-create-sqs-queues.sh`

Foi usada a variável:

```sh
MAX_RECEIVE_COUNT=4
```

Ela entra na `RedrivePolicy` assim:

```json
{
  "deadLetterTargetArn": "...",
  "maxReceiveCount": "4"
}
```

Na prática:

- a mensagem pode falhar `4` vezes na fila principal
- quando excede esse limite, o SQS move a mensagem para a DLQ

### 1.3. Onde configurei o `VisibilityTimeout`

Também no script:

- `docker/localstack/init/01-create-sqs-queues.sh`

Valores usados:

- `video-uploaded-queue` -> `900s`
- `video-status-api-queue` -> `120s`
- `video-status-notification-queue` -> `120s`

### 1.4. Por que o Java também precisou ser alterado

Se o listener captura o erro e não relança, o framework pode entender que o processamento terminou com sucesso.

Ou seja:

- não faz retry
- não envia para DLQ

Por isso foram ajustados os listeners:

- `video-worker-service/src/main/java/br/com/fiapx/videoworker/listener/VideoProcessingListener.java`
- `notification-service/src/main/java/br/com/fiapx/notification/listener/VideoStatusListener.java`

E também:

- `video-worker-service/src/main/java/br/com/fiapx/videoworker/service/VideoProcessingOrchestrator.java`

O objetivo foi simples:

- não engolir falha
- deixar a exceção subir
- permitir que o SQS faça retry
- permitir que o SQS envie para a DLQ quando passar do limite

---

## 2. Como pensar no fluxo da DLQ no SQS

### Fluxo mental

`Fila principal -> consumidor -> falha -> retry -> DLQ`

### Fluxo detalhado

1. a mensagem entra na fila principal
2. o consumidor recebe a mensagem
3. a mensagem fica invisível por um período (`VisibilityTimeout`)
4. se o processamento der certo, a mensagem é removida
5. se o processamento falhar e a mensagem não for confirmada/removida, ela volta
6. se isso acontecer várias vezes, o SQS move a mensagem para a DLQ

### Ponto mais importante

O SQS não entende “exceção Java” como conceito de negócio.

Ele só percebe algo equivalente a:

- a mensagem foi removida com sucesso?
- ou não foi?

### Regra mental curta

`Erro no Java -> sem confirmação -> retry no SQS -> excede limite -> DLQ`

---

## 3. Isso é padrão do SQS ou eu precisei configurar?

### Resposta curta

Os dois.

### O que já é padrão do SQS

O comportamento de retry por falha já é parte do modelo do SQS.

Se a mensagem não for confirmada/removida, ela pode voltar a ser entregue.

### O que precisa ser configurado explicitamente

A DLQ não existe sozinha.

Você precisa configurar:

- a fila principal
- a fila DLQ
- a `RedrivePolicy`
- o `maxReceiveCount`

Sem isso:

- a mensagem pode até falhar e voltar
- mas não terá uma DLQ de destino

---

## 4. Comparação visual: `SQS` x `RabbitMQ` x `Kafka`

## 4.1. SQS

### Modelo

`Fila principal -> consumidor -> falha -> retry automático -> DLQ`

### Quem controla a DLQ

- o próprio `SQS`

### Como a aplicação participa

- ela não manda diretamente para DLQ
- ela só precisa falhar de forma visível

### Configuração principal

- `RedrivePolicy`
- `maxReceiveCount`
- `VisibilityTimeout`

### Característica marcante

No `SQS`, a DLQ é mais “infraestrutura”.

---

## 4.2. RabbitMQ

### Modelo

`Fila principal -> consumidor -> nack/reject -> dead-letter-exchange -> fila de erro`

### Quem controla a DLQ

- o `broker RabbitMQ`, via configuração

### Como a aplicação participa

- o consumidor costuma trabalhar explicitamente com `ack`, `nack` e `reject`

### Configuração principal

- `dead-letter-exchange`
- `dead-letter-routing-key`
- política de requeue ou descarte

### Característica marcante

No `RabbitMQ`, a interação explícita com `ack/nack` costuma aparecer mais claramente no consumidor.

---

## 4.3. Kafka

### Modelo

`Tópico principal -> consumidor -> falha -> retry -> DLT`

### Quem controla a DLT

- normalmente a aplicação ou o framework

### Como a aplicação participa

- controla commit de offset
- configura retry
- publica mensagem em `DLT` (`Dead Letter Topic`) quando necessário

### Configuração principal

- política de retry
- commit/rollback de offset
- tratamento de erro do framework
- publicação em tópico de erro

### Característica marcante

No `Kafka`, a DLT geralmente é menos “configuração nativa de fila” e mais “desenho de aplicação”.

---

## 5. Tabela comparativa

| Tecnologia | Unidade principal | Como falha é percebida | Quem move para erro | Estrutura de erro |
| --- | --- | --- | --- | --- |
| `SQS` | fila | mensagem não é confirmada/removida | `SQS` | `DLQ` |
| `RabbitMQ` | fila/exchange | `nack` / `reject` / ausência de `ack` | `RabbitMQ` | fila morta |
| `Kafka` | tópico | offset não commitado / retry handler | aplicação/framework | `DLT` |

---

## 6. Então, respondendo objetivamente

### Eu preciso configurar no Java que a mensagem vai para a DLQ?

Não diretamente.

Você não escreve algo como:

```java
enviarParaDlq(mensagem);
```

No caso do `SQS`, quem decide mover para DLQ é a infraestrutura.

### Então o que o Java precisa fazer?

O Java precisa:

- não mascarar a falha
- não fingir sucesso
- deixar a exceção subir

### Então o que a infraestrutura precisa fazer?

No `SQS`, a fila precisa estar configurada com:

- `RedrivePolicy`
- `maxReceiveCount`
- `VisibilityTimeout`

---

## 7. Como observar mensagens na DLQ

### Listar as filas

```bash
docker exec fiapx-localstack awslocal sqs list-queues
```

### Ler mensagens de uma DLQ

Exemplo:

```bash
docker exec fiapx-localstack awslocal sqs receive-message \
  --queue-url http://sqs.us-east-1.localhost.localstack.cloud:4566/000000000000/video-uploaded-queue-dlq \
  --attribute-names All \
  --message-attribute-names All \
  --max-number-of-messages 10
```

### Ver quantidade de mensagens

```bash
docker exec fiapx-localstack awslocal sqs get-queue-attributes \
  --queue-url http://sqs.us-east-1.localhost.localstack.cloud:4566/000000000000/video-uploaded-queue-dlq \
  --attribute-names ApproximateNumberOfMessages ApproximateNumberOfMessagesNotVisible
```

---

## 8. Como reenfileirar mensagens da DLQ

O `SQS` não faz retry automático da DLQ de volta para a fila principal.

Você precisa fazer isso manualmente.

### Fluxo

`DLQ -> ler mensagem -> reenviar para fila principal -> deletar da DLQ`

### Passo 1: ler da DLQ

```bash
docker exec fiapx-localstack awslocal sqs receive-message \
  --queue-url http://sqs.us-east-1.localhost.localstack.cloud:4566/000000000000/video-uploaded-queue-dlq \
  --max-number-of-messages 1 \
  --attribute-names All \
  --message-attribute-names All
```

### Passo 2: reenviar para a fila principal

```bash
docker exec fiapx-localstack awslocal sqs send-message \
  --queue-url http://sqs.us-east-1.localhost.localstack.cloud:4566/000000000000/video-uploaded-queue \
  --message-body '...conteudo do Body...'
```

### Passo 3: apagar da DLQ

```bash
docker exec fiapx-localstack awslocal sqs delete-message \
  --queue-url http://sqs.us-east-1.localhost.localstack.cloud:4566/000000000000/video-uploaded-queue-dlq \
  --receipt-handle '...ReceiptHandle...'
```

---

## 9. Frase pronta para apresentação

> No FIAP-X, a aplicação não envia manualmente mensagens para a DLQ. Ela apenas falha no processamento. O `SQS`, configurado com `RedrivePolicy`, detecta falhas repetidas e move automaticamente a mensagem para a DLQ após o número máximo de tentativas.

---

## 10. Resumo final

- No `SQS`, a `DLQ` é configurada na fila, não no código Java.
- O `Java` só precisa deixar a falha visível.
- Se o código captura erro e não relança, a mensagem pode ser tratada como sucesso.
- No `SQS`, quem decide mover para a `DLQ` é a infraestrutura.
- Em outras mensagerias a ideia é parecida, mas o mecanismo muda:
  - `SQS` -> `RedrivePolicy` na fila
  - `RabbitMQ` -> `dead-letter-exchange` com `ack/nack`
  - `Kafka` -> `DLT` normalmente controlada pela aplicação/framework
